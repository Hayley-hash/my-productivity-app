# My daily schedule

A Pen created on CodePen.

Original URL: [https://codepen.io/Body-of-Brilliance/pen/MYJjOeV](https://codepen.io/Body-of-Brilliance/pen/MYJjOeV).

